import { useState } from 'react';
import { useStore } from '../../store';
import { Plus, RefreshCcw } from 'lucide-react';
import type { CargoType } from '../../types';

const getRandomColor = () =>
  '#' +
  Math.floor(Math.random() * 16777215)
    .toString(16)
    .padStart(6, '0');

export const CargoForm = () => {
  const addCargo = useStore((state) => state.addCargo);

  const [newItem, setNewItem] = useState({
    width: 60,
    length: 40,
    height: 40,
    qty: 1,
    type: 'box' as CargoType,
    color: getRandomColor(),
  });

  const handleAddItem = () => {
    addCargo({
      name: `${
        newItem.type === 'cylinder'
          ? 'Rulo'
          : newItem.type === 'pallet'
          ? 'Palet'
          : 'Koli'
      }-${Math.floor(Math.random() * 100)}`,
      type: newItem.type,
      width: newItem.width,
      length: newItem.length,
      height: newItem.height,
      quantity: newItem.qty,
      color: newItem.color,
      rotationAllowed: true,
    });
    setNewItem((prev) => ({ ...prev, color: getRandomColor() }));
  };

  const getLabels = () => {
    if (newItem.type === 'cylinder')
      return { w: 'Çap (cm)', l: 'Çap (cm)', h: 'Uzunluk (cm)' };
    if (newItem.type === 'pallet')
      return { w: 'Palet Eni', l: 'Palet Boyu', h: 'Yükseklik' };
    return { w: 'En (cm)', l: 'Boy (cm)', h: 'Yükseklik (cm)' };
  };

  const labels = getLabels();

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
      <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
        <Plus size={14} /> Yeni Yük Tanımla
      </h2>

      <div className="space-y-4">
        <div className="flex bg-slate-100 p-1 rounded-lg">
          {['box', 'cylinder', 'pallet'].map((t) => (
            <button
              key={t}
              onClick={() => setNewItem({ ...newItem, type: t as any })}
              className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
                newItem.type === t
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-slate-500'
              }`}
            >
              {t === 'box' ? 'Koli' : t === 'cylinder' ? 'Rulo' : 'Palet'}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
              Adet
            </label>
            <input
              type="number"
              min="1"
              className="w-full h-9 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg outline-none"
              value={newItem.qty}
              onChange={(e) => setNewItem({ ...newItem, qty: +e.target.value })}
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
              Renk
            </label>
            <div className="flex gap-2">
              <div className="flex-1 h-9 bg-slate-50 border border-slate-200 rounded-lg overflow-hidden relative">
                <input
                  type="color"
                  className="absolute w-[150%] h-[150%] -top-2 -left-2 cursor-pointer"
                  value={newItem.color}
                  onChange={(e) =>
                    setNewItem({ ...newItem, color: e.target.value })
                  }
                />
              </div>
              <button
                onClick={() =>
                  setNewItem((p) => ({ ...p, color: getRandomColor() }))
                }
                className="h-9 w-9 flex items-center justify-center bg-slate-100 rounded-lg text-slate-500 hover:bg-slate-200"
              >
                <RefreshCcw size={14} />
              </button>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
              {labels.w}
            </label>
            <input
              type="number"
              className="w-full h-9 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg outline-none"
              value={newItem.width}
              onChange={(e) =>
                setNewItem({ ...newItem, width: +e.target.value })
              }
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
              {labels.l}
            </label>
            <input
              type="number"
              className="w-full h-9 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg outline-none"
              disabled={newItem.type === 'cylinder'}
              value={
                newItem.type === 'cylinder' ? newItem.width : newItem.length
              }
              onChange={(e) =>
                setNewItem({ ...newItem, length: +e.target.value })
              }
            />
          </div>
          <div className="col-span-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
              {labels.h}
            </label>
            <input
              type="number"
              className="w-full h-9 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg outline-none"
              value={newItem.height}
              onChange={(e) =>
                setNewItem({ ...newItem, height: +e.target.value })
              }
            />
          </div>
        </div>

        <button
          onClick={handleAddItem}
          className="w-full h-10 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-lg shadow-md flex justify-center items-center gap-2"
        >
          <Plus size={16} /> LİSTEYE EKLE
        </button>
      </div>
    </div>
  );
};
