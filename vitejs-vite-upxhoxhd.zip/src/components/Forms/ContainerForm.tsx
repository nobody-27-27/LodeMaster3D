import { useState } from 'react';
import { useStore } from '../../store';
import { Settings, Container as ContainerIcon } from 'lucide-react';

const CONTAINER_PRESETS = [
  {
    id: 'std-truck',
    name: 'Standart Tır',
    width: 248,
    length: 1360,
    height: 270,
  },
  {
    id: '40-hc',
    name: '40 HC Konteyner',
    width: 235,
    length: 1203,
    height: 269,
  },
  {
    id: '40-dc',
    name: '40 DC Konteyner',
    width: 235,
    length: 1203,
    height: 239,
  },
  {
    id: '20-dc',
    name: '20 DC Konteyner',
    width: 235,
    length: 590,
    height: 239,
  },
  { id: 'custom', name: 'Özel Tanım', width: 300, length: 1000, height: 250 },
];

export const ContainerForm = () => {
  const { container, setContainer } = useStore();
  const [selectedPreset, setSelectedPreset] = useState('std-truck');

  const handlePresetChange = (presetId: string) => {
    setSelectedPreset(presetId);
    const preset = CONTAINER_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      setContainer({
        ...container,
        name: preset.name,
        width: preset.width,
        length: preset.length,
        height: preset.height,
      });
    }
  };

  const handleDimensionChange = (key: string, value: number) => {
    setSelectedPreset('custom');
    setContainer({ ...container, name: 'Özel Araç', [key]: value });
  };

  return (
    <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
      <div className="absolute top-0 right-0 p-2 opacity-10">
        <ContainerIcon size={64} className="text-slate-800" />
      </div>

      <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
        <Settings size={14} /> Araç Ayarları
      </h2>

      <div className="space-y-4 relative z-10">
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
            Araç Tipi
          </label>
          <select
            className="w-full h-9 px-2 text-sm bg-white border border-slate-300 rounded-lg outline-none cursor-pointer"
            value={selectedPreset}
            onChange={(e) => handlePresetChange(e.target.value)}
          >
            {CONTAINER_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {['width', 'length', 'height'].map((dim) => (
            <div key={dim}>
              <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">
                {dim === 'width'
                  ? 'Genişlik'
                  : dim === 'length'
                  ? 'Uzunluk'
                  : 'Yükseklik'}
              </label>
              <input
                type="number"
                className="w-full h-8 px-2 text-sm text-center font-mono bg-white border border-slate-300 rounded outline-none"
                value={container[dim as keyof typeof container] as number}
                onChange={(e) => handleDimensionChange(dim, +e.target.value)}
              />
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-slate-200">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold text-blue-600 uppercase">
              Palet Yan Boşluğu
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                step="1"
                className="w-16 h-8 px-2 text-sm text-center font-bold bg-blue-50 border border-blue-200 rounded text-blue-700 outline-none"
                value={container.gap || 0}
                onChange={(e) =>
                  setContainer({ ...container, gap: +e.target.value })
                }
              />
              <span className="text-xs text-slate-400">cm</span>
            </div>
          </div>
          <p className="text-[9px] text-slate-400 mt-1 leading-tight">
            * Sadece paletli yüklerde ve sadece genişlik (sağ-sol) yönünde
            uygulanır.
          </p>
        </div>
      </div>
    </div>
  );
};
