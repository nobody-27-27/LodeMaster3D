import { Canvas } from '@react-three/fiber';
import {
  OrbitControls,
  Grid,
  GizmoHelper,
  GizmoViewport,
} from '@react-three/drei';
import { useStore } from '../store';
import * as THREE from 'three';
import type { PlacedItem } from '../types';

const CargoMesh = ({ item }: { item: PlacedItem }) => {
  // Sadece Geometriyi Belirle
  let meshGeometry;

  if (item.type === 'cylinder') {
    let height = 0;
    let radius = 0;

    if (item.orientation === 'lying-x') {
      height = item.dimensions[0];
      radius = item.dimensions[1] / 2;
    } else if (item.orientation === 'lying-z') {
      height = item.dimensions[2];
      radius = item.dimensions[1] / 2;
    } else {
      height = item.dimensions[1];
      radius = item.dimensions[0] / 2;
    }
    // Silindir Geometrisi
    meshGeometry = new THREE.CylinderGeometry(radius, radius, height, 32);
  } else {
    // Kutu Geometrisi
    meshGeometry = new THREE.BoxGeometry(...item.dimensions);
  }

  return (
    <group position={item.position} rotation={item.rotation}>
      <mesh castShadow receiveShadow geometry={meshGeometry}>
        <meshStandardMaterial
          color={item.color}
          roughness={0.3} // Biraz daha mat yapalım, gerçekçi durur
          metalness={0.1}
        />
        {/* İsteğe bağlı: Hafif bir kenar çizgisi (Sadece şeklin kendisi için, kutu değil) */}
        {/* Eğer rulolar aynı renkse ayırt etmek için bu ince çizgi iyi olabilir */}
        <lineSegments>
          <edgesGeometry args={[meshGeometry]} />
          <lineBasicMaterial color="black" opacity={0.15} transparent />
        </lineSegments>
      </mesh>
    </group>
  );
};

// ... ContainerBoundaries ve Scene bileşenleri AYNI KALACAK ...
// (Dosyanın geri kalanını değiştirmene gerek yok)

const ContainerBoundaries = () => {
  const container = useStore((state) => state.container);
  return (
    <group>
      <mesh
        position={[container.width / 2, -0.6, container.length / 2]}
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
      >
        <planeGeometry args={[container.width + 50, container.length + 50]} />
        <meshStandardMaterial color="#f1f5f9" side={THREE.DoubleSide} />
      </mesh>
      <lineSegments
        position={[
          container.width / 2,
          container.height / 2,
          container.length / 2,
        ]}
      >
        <edgesGeometry
          args={[
            new THREE.BoxGeometry(
              container.width,
              container.height,
              container.length
            ),
          ]}
        />
        <lineBasicMaterial color="#334155" linewidth={2} />
      </lineSegments>
      <mesh position={[container.width / 2, 1, 0]}>
        <boxGeometry args={[container.width, 2, 5]} />
        <meshStandardMaterial color="#ef4444" />
      </mesh>
    </group>
  );
};

export const Scene = () => {
  const placedItems = useStore((state) => state.placedItems);
  const container = useStore((state) => state.container);

  return (
    <div className="h-full w-full bg-slate-200">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: [600, 800, 1000], fov: 45, near: 1, far: 20000 }}
      >
        <color attach="background" args={['#e2e8f0']} />
        <ambientLight intensity={0.6} />
        <directionalLight
          position={[500, 1000, 500]}
          intensity={1.2}
          castShadow
          shadow-mapSize={[2048, 2048]}
          shadow-bias={-0.0005}
        >
          <orthographicCamera
            attach="shadow-camera"
            args={[-1000, 1000, 1000, -1000]}
          />
        </directionalLight>
        <group>
          <ContainerBoundaries />
          {placedItems.map((item) => (
            <CargoMesh key={item.uniqueId} item={item} />
          ))}
        </group>
        <Grid
          position={[0, -0.5, 0]}
          args={[5000, 5000]}
          cellColor="#cbd5e1"
          sectionColor="#94a3b8"
          fadeDistance={4000}
        />
        <OrbitControls
          makeDefault
          minPolarAngle={0}
          maxPolarAngle={Math.PI / 2}
        />
        <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
          <GizmoViewport
            axisColors={['#ef4444', '#22c55e', '#3b82f6']}
            labelColor="black"
          />
        </GizmoHelper>
      </Canvas>
    </div>
  );
};
