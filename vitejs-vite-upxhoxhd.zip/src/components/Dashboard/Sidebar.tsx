import { Truck, Play, RefreshCw, FilePlus } from 'lucide-react';
import { useStore } from '../../store';
import { ContainerForm } from '../Forms/ContainerForm';
import { CargoForm } from '../Forms/CargoForm';
import { CargoList } from '../Lists/CargoList';
import { SimulationStats } from './SimulationStats'; // YENİ IMPORT
import { runSimpleSimulation } from '../../utils/solver';

export const Sidebar = () => {
  const {
    cargoList,
    container,
    setSimulationResult,
    setIsCalculating,
    resetProject,
    placedItems,
  } = useStore();

  const handleCalculate = () => {
    debugger;
    setIsCalculating(true);
    setTimeout(() => {
      const results = runSimpleSimulation(container, cargoList);
      // setPlacedItems YERİNE setSimulationResult kullanıyoruz
      setSimulationResult(
        results.placedItems,
        results.unplacedItems,
        results.stats
      );
      console.log(results);
      setIsCalculating(false);
    }, 600);
  };

  const handleReset = () => {
    if (
      window.confirm(
        'Tüm proje ve yükler silinecek. Yeni bir projeye başlamak istiyor musunuz?'
      )
    ) {
      resetProject();
    }
  };

  const hasResults = placedItems.length > 0;

  return (
    <aside className="w-[380px] min-w-[380px] bg-white border-r border-slate-200 flex flex-col shadow-xl z-20 h-full">
      {/* Header */}
      <div className="h-16 flex items-center justify-between px-6 border-b border-slate-100 bg-white shadow-sm z-10">
        <div className="flex items-center gap-2 text-blue-700">
          <Truck size={24} strokeWidth={2} />
          <h1 className="text-lg font-extrabold tracking-tight">
            LODEMASTER <span className="text-slate-400 font-normal">3D</span>
          </h1>
        </div>
        <button
          onClick={handleReset}
          className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          title="Yeni Proje"
        >
          <FilePlus size={20} />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
        {/* Hesaplama yapıldıysa İstatistikleri göster, yapılmadıysa formları */}
        {hasResults ? (
          <>
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-sm font-bold text-slate-700">
                Simülasyon Raporu
              </h2>
              <button
                onClick={() =>
                  setSimulationResult([], [], useStore.getState().stats)
                } // Basitçe sonuç görünümünden çık (gerçek reset değil)
                className="text-xs text-blue-600 hover:underline"
              >
                Ayarlara Dön
              </button>
            </div>
            <SimulationStats />

            {/* Sonuç varken listeyi de altta göstermeye devam edelim ama pasif */}
            <div className="opacity-50 pointer-events-none mt-6">
              <CargoList />
            </div>
          </>
        ) : (
          <>
            <ContainerForm />
            <CargoForm />
            <CargoList />
          </>
        )}
      </div>

      {/* Footer - Eğer sonuç varsa 'Yeniden Hesapla' butonuna dönüşebilir */}
      <div className="p-5 border-t border-slate-200 bg-white">
        <button
          onClick={handleCalculate}
          disabled={cargoList.length === 0}
          className={`w-full h-12 rounded-xl text-white font-bold text-base shadow-xl flex items-center justify-center gap-2 transition-all transform active:scale-95 ${
            cargoList.length === 0
              ? 'bg-slate-300 cursor-not-allowed shadow-none'
              : 'bg-green-600 hover:bg-green-700 shadow-green-200'
          }`}
        >
          {hasResults ? (
            <RefreshCw size={20} />
          ) : (
            <Play size={20} fill="currentColor" />
          )}
          {hasResults ? 'YENİDEN HESAPLA' : 'SİMÜLASYONU BAŞLAT'}
        </button>
      </div>
    </aside>
  );
};
