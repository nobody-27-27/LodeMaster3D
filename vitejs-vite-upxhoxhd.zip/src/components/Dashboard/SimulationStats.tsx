import { useMemo } from 'react';
import { useStore } from '../../store';
import { PieChart, AlertCircle, CheckCircle2, PackageX } from 'lucide-react';
import type { CargoItem } from '../../types';

export const SimulationStats = () => {
  const { stats, unplacedItems } = useStore();

  // SIĞMAYANLARI GRUPLA
  // Tekil liste halindeki (örn: 50 tane aynı kutu) veriyi analiz edip gruplar.
  const groupedUnplaced = useMemo(() => {
    const groups: Record<string, CargoItem> = {};

    unplacedItems.forEach((item) => {
      // Gruplama Anahtarı: Tip + En + Boy + Yükseklik + Renk
      // Bu özellikleri aynı olanlar aynı grupta toplanır.
      const key = `${item.type}-${item.width}-${item.length}-${item.height}-${item.color}`;

      if (!groups[key]) {
        // Grubu başlat (ilk eleman)
        groups[key] = { ...item, quantity: 0 };
      }
      // Adeti artır
      groups[key].quantity += 1;
    });

    return Object.values(groups);
  }, [unplacedItems]);

  if (stats.totalItems === 0) return null;

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* 1. ÖZET KARTI */}
      <div className="bg-slate-800 text-white p-4 rounded-xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <PieChart size={80} />
        </div>

        <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">
          Doluluk Oranı
        </h3>
        <div className="flex items-end gap-2 mb-4">
          <span className="text-4xl font-bold text-green-400">
            %{stats.efficiency.toFixed(1)}
          </span>
          <span className="text-xs text-slate-400 mb-1">Hacimsel</span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs border-t border-slate-700 pt-3">
          <div>
            <span className="block text-slate-500">Toplam Hacim</span>
            <span className="font-mono font-bold">
              {stats.totalVolume.toFixed(2)} m³
            </span>
          </div>
          <div>
            <span className="block text-slate-500">Kullanılan</span>
            <span className="font-mono font-bold text-green-400">
              {stats.usedVolume.toFixed(2)} m³
            </span>
          </div>
        </div>
      </div>

      {/* 2. SIĞMAYANLAR LİSTESİ (GRUPLU GÖSTERİM) */}
      {stats.unplacedCount > 0 ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3 text-red-700">
            <AlertCircle size={18} />
            <h3 className="font-bold text-sm">
              Sığmayan Yükler ({stats.unplacedCount})
            </h3>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
            {groupedUnplaced.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between bg-white p-2.5 rounded border border-red-100 text-xs shadow-sm"
              >
                <div className="flex items-center gap-3">
                  {/* Renk Kutucuğu ve Adet */}
                  <div
                    className="h-8 w-8 rounded flex items-center justify-center text-white font-bold text-[10px] shadow-sm"
                    style={{ backgroundColor: item.color }}
                  >
                    {item.quantity}
                  </div>

                  <div>
                    <div className="font-bold text-slate-700 flex items-center gap-1">
                      {item.type === 'cylinder'
                        ? 'RULO'
                        : item.type === 'pallet'
                        ? 'PALET'
                        : 'KOLİ'}
                    </div>
                    <div className="font-mono text-slate-500 text-[10px]">
                      {item.width} x {item.length} x {item.height} cm
                    </div>
                  </div>
                </div>

                {/* Uyarı İkonu */}
                <PackageX size={16} className="text-red-300" />
              </div>
            ))}
          </div>
          <p className="text-[10px] text-red-500 mt-3 font-medium border-t border-red-200 pt-2">
            * Öneri: Araç boyutunu büyütmeyi veya yükleme sırasını değiştirmeyi
            deneyin.
          </p>
        </div>
      ) : (
        /* Hepsi Sığdıysa Başarı Mesajı */
        <div className="bg-green-50 border border-green-200 rounded-xl p-3 flex items-center gap-3">
          <CheckCircle2 size={24} className="text-green-600" />
          <div>
            <h3 className="font-bold text-sm text-green-800">
              Tüm Yükler Sığdı!
            </h3>
            <p className="text-[10px] text-green-600">
              Toplam {stats.placedCount} parça başarıyla yerleştirildi.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
