import { useStore } from '../../store';
import { Layers, Trash2, Box, RotateCcw } from 'lucide-react';

export const CargoList = () => {
  const { cargoList, removeCargo, resetProject } = useStore();

  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Layers size={14} /> Yük Listesi
        </h2>
        {cargoList.length > 0 && (
          <button
            onClick={resetProject}
            className="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-1 rounded flex items-center gap-1 hover:bg-red-100 transition-colors"
          >
            <RotateCcw size={10} /> HEPSİNİ SİL
          </button>
        )}
      </div>

      <div className="space-y-2 pb-10">
        {cargoList.length === 0 && (
          <div className="text-center py-8 px-4 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl">
            <Box className="mx-auto text-slate-300 mb-2" size={32} />
            <p className="text-xs text-slate-500">
              Liste boş. Yukarıdan yük ekleyin.
            </p>
          </div>
        )}
        {cargoList.map((item) => (
          <div
            key={item.id}
            className="group relative bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex justify-between hover:border-blue-400 transition-all"
          >
            <div className="flex gap-3">
              <div
                className="w-10 h-10 rounded-md shadow-sm flex items-center justify-center text-white text-xs font-bold"
                style={{ backgroundColor: item.color }}
              >
                {item.quantity}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-700 uppercase">
                  {item.type === 'cylinder'
                    ? 'RULO'
                    : item.type === 'pallet'
                    ? 'PALET'
                    : 'KOLİ'}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {item.type === 'cylinder'
                    ? `Ø${item.width} x H:${item.height}`
                    : `${item.width}x${item.length}x${item.height}`}
                </div>
              </div>
            </div>
            <button
              onClick={() => removeCargo(item.id)}
              className="text-slate-300 hover:text-red-500 transition-colors"
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
