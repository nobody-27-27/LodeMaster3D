import { Sidebar } from './components/Dashboard/Sidebar';
import { Scene } from './components/Scene';
import { useStore } from './store';
import { Truck } from 'lucide-react';

export default function App() {
  const { container, placedItems } = useStore();

  return (
    <div className="flex h-screen w-screen bg-slate-50 overflow-hidden font-sans text-slate-800">
      {/* SOL PANEL */}
      <Sidebar />

      {/* SAĞ PANEL (3D SAHNE) */}
      <main className="flex-1 relative bg-slate-100 h-full">
        <Scene />

        {/* Bilgi Kartı - Scene içinde de olabilir ama burada UI katmanı olarak durması daha iyi */}
        <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-4 py-3 rounded-xl shadow-lg border border-white/50 min-w-[200px]">
          <div className="flex items-center gap-3 mb-2 border-b border-slate-100 pb-2">
            <div className="p-1.5 bg-blue-100 text-blue-600 rounded-md">
              <Truck size={16} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800 leading-tight">
                {container.name}
              </h3>
              <p className="text-[10px] text-slate-400">Aktif Araç</p>
            </div>
          </div>
          <div className="text-xs text-slate-500 font-mono space-y-1.5">
            <div className="flex justify-between">
              <span>Genişlik (X):</span>{' '}
              <span className="font-bold text-slate-700">
                {container.width} cm
              </span>
            </div>
            <div className="flex justify-between">
              <span>Uzunluk (Y):</span>{' '}
              <span className="font-bold text-slate-700">
                {container.length} cm
              </span>
            </div>
            <div className="flex justify-between">
              <span>Yükseklik (Z):</span>{' '}
              <span className="font-bold text-slate-700">
                {container.height} cm
              </span>
            </div>
            <div className="flex justify-between pt-1 border-t border-slate-100 text-blue-600">
              <span>Hacim:</span>
              <span className="font-bold">
                {(
                  (container.width * container.length * container.height) /
                  1000000
                ).toFixed(2)}{' '}
                m³
              </span>
            </div>
          </div>
        </div>

        {/* Sonuç Özeti */}
        {placedItems.length > 0 && (
          <div className="absolute bottom-6 right-6 bg-white/90 backdrop-blur-md px-6 py-4 rounded-xl shadow-xl border border-white/50 text-right">
            <div className="text-3xl font-bold text-blue-600">
              {placedItems.length}
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Yüklenen Parça
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
