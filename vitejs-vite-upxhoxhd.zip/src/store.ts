import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import type { CargoItem, Container, PlacedItem } from './types';

// İstatistik verisi için tip tanımı
interface SimulationStats {
  totalVolume: number; // Konteyner Hacmi (m3)
  usedVolume: number; // Kullanılan Hacim (m3)
  efficiency: number; // Doluluk Oranı (%)
  totalItems: number; // Toplam İstenen
  placedCount: number; // Yerleşen
  unplacedCount: number; // Yerleşemeyen
}

interface AppState {
  container: Container;
  cargoList: CargoItem[];

  // Sonuçlar
  placedItems: PlacedItem[];
  unplacedItems: CargoItem[]; // YENİ: Sığmayanlar listesi
  stats: SimulationStats; // YENİ: İstatistikler

  isCalculating: boolean;

  setContainer: (container: Container) => void;
  addCargo: (item: Omit<CargoItem, 'id'>) => void;
  removeCargo: (id: string) => void;
  setSimulationResult: (
    placed: PlacedItem[],
    unplaced: CargoItem[],
    stats: SimulationStats
  ) => void; // YENİ FONKSİYON
  setIsCalculating: (status: boolean) => void;
  resetProject: () => void;
}

const DEFAULT_CONTAINER: Container = {
  name: 'Standart Tır',
  width: 248,
  length: 1360,
  height: 270,
  gap: 0,
};

const DEFAULT_STATS: SimulationStats = {
  totalVolume: 0,
  usedVolume: 0,
  efficiency: 0,
  totalItems: 0,
  placedCount: 0,
  unplacedCount: 0,
};

export const useStore = create<AppState>((set) => ({
  container: DEFAULT_CONTAINER,
  cargoList: [],
  placedItems: [],
  unplacedItems: [],
  stats: DEFAULT_STATS,
  isCalculating: false,

  setContainer: (c) => set({ container: c }),

  addCargo: (item) =>
    set((state) => ({
      cargoList: [...state.cargoList, { ...item, id: uuidv4() }],
    })),

  removeCargo: (id) =>
    set((state) => ({
      cargoList: state.cargoList.filter((i) => i.id !== id),
      placedItems: [], // Silince sonucu temizle
      unplacedItems: [],
      stats: DEFAULT_STATS,
    })),

  // Tek seferde tüm sonuçları güncelleyen fonksiyon
  setSimulationResult: (placed, unplaced, stats) =>
    set({
      placedItems: placed,
      unplacedItems: unplaced,
      stats: stats,
    }),

  setIsCalculating: (status) => set({ isCalculating: status }),

  resetProject: () =>
    set({
      cargoList: [],
      placedItems: [],
      unplacedItems: [],
      stats: DEFAULT_STATS,
      container: DEFAULT_CONTAINER,
      isCalculating: false,
    }),
}));
