import type { IPacker } from './IPacker';
import type { Container, Orientation } from '../../../types';
import type { Box3D, PackerItem } from '../types';
import { PhysicsEngine } from '../physics';
import { getValleyCoordinates } from '../geometry';

export class CylinderPacker implements IPacker {
  private container: Container;
  private physics: PhysicsEngine;

  constructor(container: Container, physics: PhysicsEngine) {
    this.container = container;
    this.physics = physics;
  }

  private getDimensions(item: PackerItem, ori: Orientation) {
    if (ori === 'standing') return { w: item.w, h: item.h, d: item.w };
    if (ori === 'lying-z') return { w: item.w, h: item.w, d: item.h };
    return { w: item.h, h: item.w, d: item.w };
  }

  private getCandidates(
    item: PackerItem,
    ori: Orientation,
    placedItems: any[]
  ): Array<Box3D & { isValley?: boolean }> {
    const dim = this.getDimensions(item, ori);
    const rNew = dim.w / 2;
    const candidates: Array<Box3D & { isValley?: boolean }> = [];

    // 1. ZEMİN VE DUVAR DİPLERİ
    candidates.push({ x: 0, y: 0, z: 0 });
    candidates.push({ x: this.container.width - dim.w, y: 0, z: 0 });

    const cylinders = placedItems.filter((p) => p.type === 'cylinder');

    cylinders.forEach((p) => {
      if (Math.abs(p.z - 0) > 1300) return;

      // --- YATIK YERLEŞİM (STACKING) ---
      if (ori === 'lying-z') {
        // A. Yanına
        candidates.push({ x: p.x + p.w, y: p.y, z: p.z });

        // B. Dik Silindirlerin Tepesi (BU ÇOK ÖNEMLİ)
        if (p.orientation === 'standing') {
          // Tam tepesine ve X merkezine
          candidates.push({ x: p.x + p.w / 2 - rNew, y: p.y + p.h, z: p.z });

          // Eğer çaplar aynıysa, tam hizaya da koy (Hatasız hizalama için)
          if (Math.abs(p.w - dim.w) < 1.0) {
            candidates.push({ x: p.x, y: p.y + p.h, z: p.z });
          }
        }
        // C. Yatık Silindirlerin Üstü
        else if (p.orientation === 'lying-z') {
          candidates.push({ x: p.x, y: p.y + p.h, z: p.z }); // Tam üstü
          candidates.push({ x: p.x - rNew, y: p.y + p.h, z: p.z }); // Vadi
          candidates.push({ x: p.x + rNew, y: p.y + p.h, z: p.z }); // Vadi
        }
      }

      // --- DİK YERLEŞİM (FLOORING) ---
      else if (ori === 'standing' && p.orientation === 'standing') {
        // Yanına (Grid) - Temel yapı
        candidates.push({ x: p.x + p.w, y: 0, z: p.z });

        // Petek (Zig-Zag)
        const rowDepth = p.d * 0.866;
        candidates.push({
          x: p.x - rNew,
          y: 0,
          z: p.z + rowDepth,
          isValley: true,
        });
        candidates.push({
          x: p.x + rNew,
          y: 0,
          z: p.z + rowDepth,
          isValley: true,
        });
      }
    });

    // 2. VADİ TARAMASI
    for (let i = 0; i < cylinders.length; i++) {
      for (let j = i + 1; j < cylinders.length; j++) {
        const c1 = cylinders[i];
        const c2 = cylinders[j];
        if (c1.orientation !== c2.orientation) continue;

        // Yatık Vadisi
        if (ori === 'lying-z' && c1.orientation === 'lying-z') {
          if (Math.abs(c1.z - c2.z) > 50) continue;
          const valley = getValleyCoordinates(
            { x: c1.x + c1.w / 2, y: c1.y + c1.w / 2, r: c1.w / 2 },
            { x: c2.x + c2.w / 2, y: c2.y + c2.w / 2, r: c2.w / 2 },
            rNew
          );
          if (valley)
            candidates.push({
              x: valley.x - rNew,
              y: valley.y - rNew,
              z: Math.max(c1.z, c2.z),
              isValley: true,
            });
        }

        // Dik Vadisi
        if (ori === 'standing' && c1.orientation === 'standing') {
          if (Math.abs(c1.y - c2.y) > 5) continue;
          const valley = getValleyCoordinates(
            { x: c1.x + c1.w / 2, y: c1.z + c1.w / 2, r: c1.w / 2 },
            { x: c2.x + c2.w / 2, y: c2.z + c2.w / 2, r: c2.w / 2 },
            rNew
          );
          if (valley)
            candidates.push({
              x: valley.x - rNew,
              y: 0,
              z: valley.y - rNew,
              isValley: true,
            });
        }
      }
    }

    // Brute Force (Yedek)
    if (ori === 'standing') {
      for (let x = 0; x < this.container.width - dim.w; x += 10)
        candidates.push({ x: x, y: 0, z: 0 });
    }

    return candidates.map((c) => ({ ...c, w: dim.w, h: dim.h, d: dim.d }));
  }

  // DESTEK KONTROLÜ
  private checkSupport(cand: Box3D, placedItems: any[]): boolean {
    if (cand.y < 5) return true; // Zemin

    const candCenter = cand.x + cand.w / 2;

    for (const p of placedItems) {
      // DİK ÜSTÜNE YATIK
      if (p.orientation === 'standing') {
        // Yükseklik farkı 2cm'den az olmalı (Physics snap yaptı)
        if (Math.abs(p.y + p.h - cand.y) < 2.0) {
          const pLeft = p.x;
          const pRight = p.x + p.w;
          // Merkez noktası alttakinin içindeyse (Toleranslı)
          if (candCenter >= pLeft - 5 && candCenter <= pRight + 5) return true;
        }
      }
      // YATIK ÜSTÜNE YATIK
      else if (p.orientation === 'lying-z') {
        const r1 = cand.w / 2;
        const r2 = p.w / 2;
        const distSq =
          Math.pow(cand.x + r1 - (p.x + r2), 2) +
          Math.pow(cand.y + r1 - (p.y + r2), 2);
        if (distSq <= Math.pow(r1 + r2 + 2.0, 2)) return true;
      }
    }
    return false;
  }

  public packItem(
    item: PackerItem,
    placedItems: Array<Box3D & { type: any; orientation: Orientation }>,
    forceOrientation?: Orientation
  ): {
    placed: (Box3D & { orientation: Orientation; finalZ?: number }) | null;
  } {
    let trials: Orientation[] = [];
    const canStand = item.h < this.container.height;

    if (forceOrientation) {
      if (forceOrientation === 'standing' && !canStand) return { placed: null };
      trials = [forceOrientation];
    } else {
      trials = canStand
        ? ['standing', 'lying-z', 'lying-x']
        : ['lying-z', 'lying-x'];
    }

    let bestRes: any = null;
    let minScore = Infinity;

    for (const ori of trials) {
      const candidates = this.getCandidates(item, ori, placedItems);

      for (const cand of candidates) {
        const finalZ = this.physics.calculateRestingZ(cand, placedItems, ori);
        const boxZ = { ...cand, z: finalZ };
        const finalY = this.physics.calculateRestingY(boxZ, placedItems, ori);
        const finalBox = { ...boxZ, y: finalY };

        if (isNaN(finalY) || isNaN(finalZ)) continue;
        // 5cm boşluk toleransı
        if (finalY + finalBox.h > this.container.height + 0.9) continue;

        if (this.physics.checkCollision(finalBox, placedItems, 'cylinder', ori))
          continue;
        if (!this.checkSupport(finalBox, placedItems)) continue;

        // --- DENGELİ PUANLAMA ---
        let score = 0;

        // 1. Z-EKSENİ (Standart): Arkadakiler iyidir.
        score += finalZ * 10;

        // 2. Y-EKSENİ (KAT ÇIKMA TEŞVİĞİ):
        if (ori === 'standing') {
          // Dik rulo zeminde olmalı
          if (cand.isValley) score -= 200; // Petek ödülü
          else score += 0; // Grid cezası yok, gerekirse Grid yap
          score += finalBox.x * 0.1;
        } else {
          // Yatık rulo yukarıdaysa ödül ver
          if (finalY > 50) {
            score -= 5000; // Makul bir ödül (Zemine gitmesin ama Z'de çok ilerlemesin)
          } else {
            score += finalY * 5;
          }
          if (cand.isValley) score -= 500;
        }

        if (score < minScore) {
          minScore = score;
          bestRes = { ...finalBox, orientation: ori, finalZ: finalZ };
        }
      }
    }
    return { placed: bestRes };
  }
}
