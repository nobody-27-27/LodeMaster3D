import type { IPacker } from './IPacker';
import type { Container, Orientation } from '../../../types';
import type { Box3D, PackerItem } from '../types';
import { PhysicsEngine } from '../physics';

export class BoxPacker implements IPacker {
  private container: Container;
  private physics: PhysicsEngine;
  private freeSpaces: Box3D[];

  constructor(container: Container, physics: PhysicsEngine) {
    this.container = container;
    this.physics = physics;
    this.freeSpaces = [
      {
        x: 0,
        y: 0,
        z: 0,
        w: container.width,
        h: container.height,
        d: container.length,
      },
    ];
  }

  // UYUMLU İMZA
  public packItem(
    item: PackerItem,
    placedItems: Array<Box3D & { type: any; orientation: Orientation }>,
    forceOrientation?: Orientation
  ): {
    placed: (Box3D & { orientation: Orientation; finalZ?: number }) | null;
  } {
    // Kutularda forceOrientation şimdilik basitçe uygulanabilir veya yoksayılabilir
    const trials = [
      { w: item.w, h: item.h, d: item.d, ori: 'standing' },
      { w: item.d, h: item.h, d: item.w, ori: 'rotated' },
    ] as const;

    this.freeSpaces.sort((a, b) =>
      Math.abs(a.z - b.z) > 1
        ? a.z - b.z
        : Math.abs(a.y - b.y) > 1
        ? a.y - b.y
        : a.x - b.x
    );

    for (const space of this.freeSpaces) {
      for (const t of trials) {
        // Eğer forceOrientation varsa ve 'standing' değilse (kutular için genelde standing) atla
        // Şimdilik kutular için esnek bırakıyoruz

        if (t.w <= space.w && t.h <= space.h && t.d <= space.d) {
          const candidate = {
            x: space.x,
            y: space.y,
            z: space.z,
            w: t.w,
            h: t.h,
            d: t.d,
          };
          if (
            !this.physics.checkCollision(
              candidate,
              placedItems,
              'box',
              'standing'
            )
          ) {
            const placed = {
              ...candidate,
              orientation: 'standing' as Orientation,
            };
            this.splitSpace(space, t.w, t.h, t.d);
            return { placed };
          }
        }
      }
    }
    return { placed: null };
  }

  private splitSpace(space: Box3D, w: number, h: number, d: number) {
    this.freeSpaces = this.freeSpaces.filter((s) => s !== space);
    if (space.w - w > 0)
      this.freeSpaces.push({
        x: space.x + w,
        y: space.y,
        z: space.z,
        w: space.w - w,
        h: space.h,
        d: space.d,
      });
    if (space.h - h > 0)
      this.freeSpaces.push({
        x: space.x,
        y: space.y + h,
        z: space.z,
        w: w,
        h: space.h - h,
        d: d,
      });
    if (space.d - d > 0)
      this.freeSpaces.push({
        x: space.x,
        y: space.y,
        z: space.z + d,
        w: w,
        h: h,
        d: space.d - d,
      });
  }
}
