import type { PackerItem, Box3D } from '../types';
import type { Orientation } from '../../../types';

export interface IPacker {
  packItem(
    item: PackerItem,
    placedItems: Array<Box3D & { type: any; orientation: Orientation }>,
    forceOrientation?: Orientation
  ): {
    placed: (Box3D & { orientation: Orientation; finalZ?: number }) | null;
  };
}
