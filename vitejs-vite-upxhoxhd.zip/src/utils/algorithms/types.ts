import type { CargoType } from '../../types';

export interface Box3D {
  x: number;
  y: number; // Yükseklik ekseni (Three.js'de Y yukarı bakar)
  z: number; // Derinlik
  w: number; // Width
  h: number; // Height
  d: number; // Depth (Length)
}

export interface PackerItem {
  id: string;
  originalId: string; // Kargonun asıl ID'si
  type: CargoType;
  w: number;
  h: number;
  d: number;
  vol: number;
  color: string;
}

export interface PackingResult {
  placedItems: Array<
    Box3D & {
      id: string;
      color: string;
      type: CargoType;
    }
  >;
  unplacedItems: PackerItem[];
  volumeEfficiency: number;
}
