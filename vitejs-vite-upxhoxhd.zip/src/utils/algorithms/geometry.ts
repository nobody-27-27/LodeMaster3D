import type { Box3D } from './types';

// Kutu Çarpışması (Çok Toleranslı)
export const checkAABBCollision = (
  box1: Box3D,
  box2: Box3D,
  tolerance: number = 0.1
): boolean => {
  return (
    box1.x < box2.x + box2.w - tolerance &&
    box1.x + box1.w > box2.x + tolerance &&
    box1.y < box2.y + box2.h - tolerance &&
    box1.y + box1.h > box2.y + tolerance &&
    box1.z < box2.z + box2.d - tolerance &&
    box1.z + box1.d > box2.z + tolerance
  );
};

// Daire Çarpışması
export const checkCircleCollision = (
  x1: number,
  y1: number,
  r1: number,
  x2: number,
  y2: number,
  r2: number,
  tolerance: number = 0.1
): boolean => {
  const distSq = Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2);
  // Yarıçaplar toplamından tolerans kadar azsa çarpışma yok sayılabilir (Sıkıştırma)
  const minDist = r1 + r2 - tolerance;
  return distSq < Math.pow(minDist, 2);
};

// Nesting Hesabı
export const calculateNestingPos = (
  fixedPos: number,
  fixedR: number,
  movingR: number,
  crossDist: number
): number | null => {
  const radiusSum = fixedR + movingR;
  // Çok az bir farkla temas etmiyorsa bile temas ettir (Snap)
  if (crossDist >= radiusSum - 0.05) return null;

  const val = Math.pow(radiusSum, 2) - Math.pow(crossDist, 2);
  if (val < 0) return null;
  return fixedPos + Math.sqrt(val);
};

// Vadi Hesaplayıcı
export const getValleyCoordinates = (
  c1: { x: number; y: number; r: number },
  c2: { x: number; y: number; r: number },
  rNew: number
): { x: number; y: number } | null => {
  const dx = c2.x - c1.x;
  const dy = c2.y - c1.y;
  const d2 = dx * dx + dy * dy;
  const d = Math.sqrt(d2);

  const R1 = c1.r + rNew;
  const R2 = c2.r + rNew;

  if (d > R1 + R2 + 1.0 || d < Math.abs(R1 - R2) + 0.1 || d === 0) return null;

  const a = (R1 * R1 - R2 * R2 + d2) / (2 * d);
  const insideSqrt = R1 * R1 - a * a;
  if (insideSqrt < 0) return null;

  const h = Math.sqrt(insideSqrt);
  const x2 = c1.x + (a * dx) / d;
  const y2 = c1.y + (a * dy) / d;

  const resX = x2 - (h * dy) / d;
  const resY = y2 + (h * dx) / d;

  if (isNaN(resX) || isNaN(resY)) return null;

  return { x: resX, y: resY };
};
