import type { Container } from '../../types';
import type { PackerItem, PackingResult } from './types';
import { PhysicsEngine } from './physics';
import { BoxPacker } from './packers/BoxPacker';
import { CylinderPacker } from './packers/CylinderPacker';

export class BinPacker {
  private container: Container;

  constructor(container: Container) {
    this.container = container;
  }

  private simulate(
    originalItems: PackerItem[],
    config: {
      sort: 'VOLUME' | 'DIAMETER' | 'LENGTH';
      mode: 'VERTICAL' | 'HORIZONTAL' | 'HYBRID_SMART' | 'MIXED_CHAOS';
    }
  ): PackingResult {
    const physics = new PhysicsEngine(this.container);
    const boxPacker = new BoxPacker(this.container, physics);
    const cylinderPacker = new CylinderPacker(this.container, physics);
    const placedItems: any[] = [];
    const unplaced: PackerItem[] = [];

    const items = [...originalItems].sort((a, b) => {
      if (a.type !== 'cylinder' || b.type !== 'cylinder') return b.vol - a.vol;
      if (config.sort === 'DIAMETER') return b.w - a.w;
      if (config.sort === 'LENGTH') return b.h - a.h;
      return b.vol - a.vol;
    });

    for (const item of items) {
      let res: any = { placed: null };
      if (item.type === 'cylinder') {
        const canStand = item.h < this.container.height;
        switch (config.mode) {
          case 'VERTICAL':
            if (canStand)
              res = cylinderPacker.packItem(item, placedItems, 'standing');
            break;
          case 'HORIZONTAL':
            res = cylinderPacker.packItem(item, placedItems, 'lying-z');
            if (!res.placed)
              res = cylinderPacker.packItem(item, placedItems, 'lying-x');
            break;
          case 'HYBRID_SMART':
            // Puanlama motoru en iyisini seçecek
            res = cylinderPacker.packItem(item, placedItems);
            break;
          case 'MIXED_CHAOS':
            res = cylinderPacker.packItem(item, placedItems);
            break;
        }
      } else {
        res = boxPacker.packItem(item, placedItems);
      }

      if (res.placed) {
        placedItems.push({
          ...res.placed,
          id: item.originalId,
          color: item.color,
          type: item.type,
        });
      } else {
        unplaced.push(item);
      }
    }

    let vol = 0;
    placedItems.forEach((i) => (vol += i.w * i.h * i.d));

    return {
      placedItems,
      unplacedItems: unplaced,
      volumeEfficiency:
        (vol /
          (this.container.width *
            this.container.height *
            this.container.length)) *
        100,
    };
  }

  public pack(items: PackerItem[]): PackingResult {
    console.log(`Starting Optimization. Items: ${items.length}`);

    const strategies = [
      { mode: 'HYBRID_SMART', sort: 'DIAMETER', name: 'Smart Stack (Dia)' }, // Favori
      { mode: 'HYBRID_SMART', sort: 'LENGTH', name: 'Smart Stack (Len)' },
      { mode: 'VERTICAL', sort: 'DIAMETER', name: 'Vertical (Dia)' },
      { mode: 'HORIZONTAL', sort: 'LENGTH', name: 'Horizontal (Len)' },
      { mode: 'MIXED_CHAOS', sort: 'LENGTH', name: 'Chaos (Len)' },
    ] as const;

    let bestResult: PackingResult | null = null;
    let maxCount = -1;
    let winner = '';

    for (const strat of strategies) {
      const res = this.simulate(items, strat);
      const count = res.placedItems.length;
      console.log(`[${strat.name}] -> ${count}/${items.length}`);

      if (count > maxCount) {
        maxCount = count;
        bestResult = res;
        winner = strat.name;
      }
      if (count === items.length) break;
    }

    console.log(`🏆 WINNER: ${winner} (${maxCount})`);
    return (
      bestResult || {
        placedItems: [],
        unplacedItems: items,
        volumeEfficiency: 0,
      }
    );
  }
}
