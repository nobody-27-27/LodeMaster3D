import type { Container, Orientation } from '../../types';
import type { Box3D } from './types';
import {
  checkAABBCollision,
  checkCircleCollision,
  calculateNestingPos,
} from './geometry';

export class PhysicsEngine {
  private container: Container;

  constructor(container: Container) {
    this.container = container;
  }

  public checkCollision(
    cand: Box3D,
    items: Array<Box3D & { type: any; orientation: Orientation }>,
    type: string,
    ori: Orientation
  ): boolean {
    // Sınır Kontrolü (Toleranslı)
    if (cand.x < -0.1 || cand.x + cand.w > this.container.width + 0.1)
      return true;
    if (cand.y < -0.1 || cand.y + cand.h > this.container.height + 0.1)
      return true;
    if (cand.z < -0.1 || cand.z + cand.d > this.container.length + 0.1)
      return true;

    for (const p of items) {
      if (!checkAABBCollision(cand, p, 0.5)) continue;

      if (type === 'cylinder' && p.type === 'cylinder') {
        // DİK - DİK
        if (ori === 'standing' && p.orientation === 'standing') {
          if (cand.y < p.y + p.h - 1.0 && cand.y + cand.h > p.y + 1.0) {
            const r1 = cand.w / 2,
              r2 = p.w / 2;
            if (
              checkCircleCollision(
                cand.x + r1,
                cand.z + r1,
                r1,
                p.x + r2,
                p.z + r2,
                r2,
                0.5
              )
            )
              return true;
          }
          continue;
        }
        // YATIK - YATIK
        if (ori === 'lying-z' && p.orientation === 'lying-z') {
          if (cand.z < p.z + p.d - 1.0 && cand.z + cand.d > p.z + 1.0) {
            const r1 = cand.w / 2,
              r2 = p.w / 2;
            if (
              checkCircleCollision(
                cand.x + r1,
                cand.y + r1,
                r1,
                p.x + r2,
                p.y + r2,
                r2,
                0.5
              )
            )
              return true;
          }
          continue;
        }
      }
      return true;
    }
    return false;
  }

  public calculateRestingZ(
    cand: Box3D,
    items: any[],
    ori: Orientation
  ): number {
    if (ori !== 'standing') return cand.z;
    let maxZ = 0;
    for (const p of items) {
      if (!checkAABBCollision({ ...cand, z: p.z }, p, 0.5)) continue;
      let pushZ = p.z + p.d;

      // Sadece Dik-Dik ise Nesting yap, diğerlerinde kutu gibi yasla
      if (p.type === 'cylinder' && p.orientation === 'standing') {
        const r1 = cand.w / 2,
          r2 = p.w / 2;
        const nesting = calculateNestingPos(
          p.z + r2,
          r2,
          r1,
          Math.abs(cand.x + r1 - (p.x + r2))
        );
        if (nesting !== null) pushZ = nesting - r1;
      }
      if (pushZ > maxZ) maxZ = pushZ;
    }
    return maxZ;
  }

  public calculateRestingY(
    cand: Box3D,
    items: any[],
    ori: Orientation
  ): number {
    let maxY = 0;
    for (const p of items) {
      if (!checkAABBCollision({ ...cand, y: p.y }, p, 0.5)) continue;

      let pushY = p.y + p.h;

      // DİK ÜSTÜNE YATIK: Nesting YOK. Direkt tepesine koy.
      if (ori === 'lying-z' && p.orientation === 'standing') {
        pushY = p.y + p.h; // Basit toplama. 160 + 0 = 160.
      }
      // YATIK ÜSTÜNE YATIK: Nesting VAR.
      else if (ori === 'lying-z' && p.orientation === 'lying-z') {
        const r1 = cand.w / 2,
          r2 = p.w / 2;
        const xDist = Math.abs(cand.x + r1 - (p.x + r2));
        const nesting = calculateNestingPos(p.y + r2, r2, r1, xDist);
        if (nesting !== null) pushY = nesting - r1;
      }

      if (pushY > maxY) maxY = pushY;
    }
    return maxY;
  }
}
