import type { CargoItem, Container, PlacedItem } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { BinPacker } from './algorithms/packer';
import type { PackerItem } from './algorithms/types';

export const runSimpleSimulation = (
  container: Container,
  cargoList: CargoItem[]
): any => {
  const packerItems: PackerItem[] = [];
  const cargoMap = new Map<string, CargoItem>();

  cargoList.forEach((cargo) => {
    cargoMap.set(cargo.id, cargo);
    for (let i = 0; i < cargo.quantity; i++) {
      // --- DÜZELTME BURADA ---
      // Rulo (Cylinder) Mantığı:
      // Formdaki "Yükseklik" (height) aslında silindirin UZUNLUĞUDUR.
      // Formdaki "En" (width) silindirin ÇAPIDIR.

      let itemW, itemH, itemD;

      if (cargo.type === 'cylinder') {
        itemW = cargo.width; // Çap
        itemD = cargo.width; // Çap (Taban daire olduğu için En=Boy)
        itemH = cargo.height; // Uzunluk (Dik durduğunda yükseklik olur) <--- BURASI DÜZELDİ (Eskiden cargo.length idi)
      } else {
        // Koli ve Palet için standart
        itemW = cargo.width;
        itemD = cargo.length;
        itemH = cargo.height;
      }

      packerItems.push({
        id: uuidv4(),
        originalId: cargo.id,
        type: cargo.type,
        w: itemW,
        h: itemH,
        d: itemD,
        vol: itemW * itemH * itemD, // Basit hacim hesabı
        color: cargo.color,
      });
    }
  });

  const packer = new BinPacker(container);
  const result = packer.pack(packerItems);

  const unplacedList = result.unplacedItems.map((item) => {
    const original = cargoMap.get(item.originalId);
    return { ...original!, quantity: 1, id: item.id };
  });

  const placedResults: PlacedItem[] = result.placedItems.map((item: any) => {
    let rotation: [number, number, number] = [0, 0, 0];

    if (item.type === 'cylinder') {
      if (item.orientation === 'lying-x') {
        // X eksenine paralel yatıyor -> Z ekseninde 90 derece dönmeli
        rotation = [0, 0, Math.PI / 2];
      } else if (item.orientation === 'lying-z') {
        // Z eksenine paralel yatıyor -> X ekseninde 90 derece dönmeli
        rotation = [Math.PI / 2, 0, 0];
      }
    }

    return {
      id: item.id,
      uniqueId: item.id,
      type: item.type,
      color: item.color,
      orientation: item.orientation,
      position: [item.x + item.w / 2, item.y + item.h / 2, item.z + item.d / 2],
      rotation: rotation,
      dimensions: [item.w, item.h, item.d],
    };
  });

  return {
    placedItems: placedResults,
    unplacedItems: unplacedList,
    stats: {
      totalVolume:
        (container.width * container.height * container.length) / 1_000_000,
      usedVolume:
        (result.volumeEfficiency / 100) *
        ((container.width * container.height * container.length) / 1_000_000),
      efficiency: result.volumeEfficiency,
      totalItems: packerItems.length,
      placedCount: result.placedItems.length,
      unplacedCount: result.unplacedItems.length,
    },
  };
};
