export type CargoType = 'box' | 'cylinder' | 'pallet';
// YENİ TİP
export type Orientation = 'standing' | 'lying-x' | 'lying-z';

export interface Dimensions {
  width: number;
  height: number;
  depth: number;
}

export interface CargoItem {
  id: string;
  name: string;
  type: CargoType;
  width: number;
  length: number;
  height: number;
  color: string;
  quantity: number;
  rotationAllowed: boolean;
}

export interface Container {
  name: string;
  width: number;
  length: number;
  height: number;
  gap: number;
}

export interface PlacedItem {
  id: string;
  uniqueId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  dimensions: [number, number, number];
  color: string;
  type: CargoType;
  orientation?: Orientation; // YENİ: Yönelim bilgisi
}
